﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ONE_STOP_SUPERMARKET
{
    public partial class Signin : Form
    {
        public Signin()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Enter teh username ");

            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("enter the password");

            }
            else
            {
                try
                {
                    SqlConnection con = new SqlConnection();
                    SqlCommand CMD = new SqlCommand("SELECT * FROM ");
                    CMD.Parameters.AddWithValue("@username", textBox1.Text);
                    CMD.Parameters.AddWithValue(@"Password", textBox2.Text);
                    SqlDataAdapter da = new SqlDataAdapter(CMD);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if(dt.Rows.Count > 0) 
                    {
                        MessageBox.Show("login successfull");

                    }
                    else
                    {
                        MessageBox.Show("username or [assword is invalid");
                    }
                }
                catch ( Exception ex)
                {
                    MessageBox.Show("" + ex);
                }

            }
        }
    }
}
