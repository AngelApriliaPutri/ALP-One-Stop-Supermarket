﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ONE_STOP_SUPERMARKET
{
    public partial class PAPERGOODS : Form
    {
        private Panel panel_main;
        public PAPERGOODS(Panel panel)
        {
            InitializeComponent();
            this.panel_main = panel;
        }

        private void PAPERGOODS_Load(object sender, EventArgs e)
        {
            for (int i = 0; i <= 4; i++)
            {
                PictureBox picturebox = new PictureBox();
                picturebox.Image = Image.FromFile($@".\FOTO PRODUK\{i+42}.jpg");
                picturebox.Size = new Size(250, 250);
                picturebox.SizeMode = PictureBoxSizeMode.Zoom;
                picturebox.Location = new Point(50, i * 300 + 80);
                this.Controls.Add(picturebox);
            }
        }
    }
}
