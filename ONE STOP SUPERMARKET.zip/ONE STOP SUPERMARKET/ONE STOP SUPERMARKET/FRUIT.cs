﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;

namespace ONE_STOP_SUPERMARKET
{
    public partial class FRUIT : Form
    {
        private Panel panel_main;
        string connectionstring = "server=localhost;uid=root;pwd=r123;database=db_supermarket";
        MySqlConnection sqlconnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlAdapter;
        string query;
        DataTable fruit = new DataTable();
        public FRUIT(Panel panel)
        {
            InitializeComponent();
            this.panel_main = panel;
        }
        private void button_cart_Click(object sender, EventArgs e)
        {
           /* CART cart = new CART();
            cart.Dock = DockStyle.Fill;
            cart.FormBorderStyle = FormBorderStyle.None;
            cart.TopLevel = false;
            cart.ControlBox = false;
            //this.panel1.Controls.Clear();
            //this.panel1.Controls.Add(cart);
            cart.Show();*/
        }

        private void FRUIT_Load(object sender, EventArgs e)
        {
            query = "select p.namaproduk, p.hargaproduk\r\nfrom produk p\r\nwhere p.kategori = 'Fruit';";
            sqlconnect = new MySqlConnection(connectionstring);
            sqlCommand = new MySqlCommand(query, sqlconnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(fruit);

            for (int i = 0; i <= 5; i++)
            {
                PictureBox picturebox = new PictureBox();
                picturebox.Image = Image.FromFile($@".\FOTO PRODUK\{i}.jpg");
                picturebox.Size = new Size(250, 250);
                picturebox.SizeMode = PictureBoxSizeMode.Zoom;
                picturebox.Location = new Point(50, i * 300 + 80);
                this.Controls.Add(picturebox);

                Label labelfruit = new Label();
                labelfruit.Text = fruit.Rows[i]["namaproduk"].ToString();
                labelfruit.AutoSize = true;
                labelfruit.Font = new Font("Ebrima", 15, FontStyle.Bold);
                labelfruit.Location = new Point(325, i * 300 + 80);
                this.Controls.Add(labelfruit);

                Label labelrp = new Label();
                labelrp.Text = "Rp.";
                labelrp.AutoSize = true;
                labelrp.Font = new Font("Ebrima", 12, FontStyle.Bold);
                labelrp.Location = new Point(325, i * 300 + 120);
                this.Controls.Add(labelrp);

                Label labelharga = new Label();
                labelharga.Text = fruit.Rows[i]["hargaproduk"].ToString();
                labelharga.AutoSize = true;
                labelharga.Font = new Font("Ebrima", 12, FontStyle.Bold);
                labelharga.Location = new Point(360, i * 300 + 120);
                this.Controls.Add(labelharga);

                Button buttonmin = new Button();
                buttonmin.Text = "-";
                buttonmin.Size = new Size(25, 20);
                buttonmin.AutoSize = true;
                buttonmin.Location = new Point(325, i * 300 + 155);
                this.Controls.Add(buttonmin);

                Label labelnol = new Label();
                labelnol.Text = "0";
                labelnol.AutoSize = true;
                labelnol.Location = new Point(360, i * 300 + 160);
                this.Controls.Add(labelnol);

                Button buttonplus = new Button();
                buttonplus.Text = "+";
                buttonplus.Size = new Size(25, 20);
                buttonplus.AutoSize = true;
                buttonplus.Tag = i;
                buttonplus.Location = new Point(380, i * 300 + 155);
                buttonplus.Click += Buttonplus_Click;
                this.Controls.Add(buttonplus);

                Button buttonbuy = new Button();
                buttonbuy.Text = "Buy";
                buttonbuy.Size = new Size(100, 35);
                buttonbuy.AutoSize = true;
                buttonbuy.Location = new Point(325, i * 300 + 200);
                this.Controls.Add(buttonbuy);

                Button buttonfav = new Button();
                buttonfav.Text = "+Favourite";
                buttonfav.Size = new Size(100, 35);
                buttonfav.AutoSize = true;
                buttonfav.Location = new Point(450, i * 300 + 200);
                this.Controls.Add(buttonfav);
            }

        }

        private void Buttonplus_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            int index = (int)button.Tag;

            // Mengakses label yang sesuai berdasarkan indeks
            foreach (Label label in Controls.OfType<Label>())
            {
                if (label.Location.Y == index * 300 + 160)
                {
                    int value = int.Parse(label.Text);
                    value++;
                    label.Text = value.ToString();
                }
            }

        }
    }
}
