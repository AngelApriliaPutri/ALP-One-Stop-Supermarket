﻿namespace ONE_STOP_SUPERMARKET
{
    partial class CLEANERS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_cart = new System.Windows.Forms.Button();
            this.button_like = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_cart
            // 
            this.button_cart.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_cart.BackgroundImage = global::ONE_STOP_SUPERMARKET.Properties.Resources.image_removebg_preview;
            this.button_cart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_cart.Location = new System.Drawing.Point(962, 12);
            this.button_cart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_cart.Name = "button_cart";
            this.button_cart.Size = new System.Drawing.Size(86, 78);
            this.button_cart.TabIndex = 34;
            this.button_cart.UseVisualStyleBackColor = false;
            // 
            // button_like
            // 
            this.button_like.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_like.BackgroundImage = global::ONE_STOP_SUPERMARKET.Properties.Resources._8f79d824d93cccf9bd3917ba5451829a_removebg_preview;
            this.button_like.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_like.Location = new System.Drawing.Point(1062, 12);
            this.button_like.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_like.Name = "button_like";
            this.button_like.Size = new System.Drawing.Size(86, 78);
            this.button_like.TabIndex = 33;
            this.button_like.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(482, 274);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 32;
            this.label3.Text = "HARGA";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(696, 200);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(322, 49);
            this.button5.TabIndex = 31;
            this.button5.Text = "LOGO ADD TO FAVORITE";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(555, 343);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 30;
            this.label1.Text = "JUMLAH";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(675, 343);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(60, 42);
            this.button4.TabIndex = 29;
            this.button4.Text = "+";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(488, 343);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(58, 42);
            this.button3.TabIndex = 28;
            this.button3.Text = "-";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(482, 209);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 20);
            this.label2.TabIndex = 27;
            this.label2.Text = "NAMA PRODUCT";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(868, 100);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(279, 55);
            this.button2.TabIndex = 25;
            this.button2.Text = "BUAT LIST FAVORITE";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(591, 100);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(255, 55);
            this.button1.TabIndex = 24;
            this.button1.Text = "BUAT LIST CART";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // CLEANERS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.button_cart);
            this.Controls.Add(this.button_like);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "CLEANERS";
            this.Text = "CLEANERS";
            this.Load += new System.EventHandler(this.CLEANERS_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_cart;
        private System.Windows.Forms.Button button_like;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}