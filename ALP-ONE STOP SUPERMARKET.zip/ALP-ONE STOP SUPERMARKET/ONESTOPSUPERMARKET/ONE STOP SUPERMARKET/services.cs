﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONE_STOP_SUPERMARKET
{
    public class services
    {
        public void buyButton()
        {

        }
    }
}
